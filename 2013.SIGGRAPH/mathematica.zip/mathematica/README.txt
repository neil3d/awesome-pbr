The files in this folder:

bo2-prefiltered-env.nb: The main notebook for working on environment map BRDF approximations for "Black Ops 2".

bo2-prefiltered-env.pdf: PDF of main notebook for people without Mathematica (or the free viewer) to look at.

groundtruthplots: A file containing ground truth plot data; loaded by bo2-prefiltered-env.nb.

bo2-prefiltered-env-precomp.nb: A notebook for computing groundtruthplots (shouldn't need to evaluate this again)

bo2-prefiltered-env-precomp.pdf: A PDF of bo2-prefiltered-env-precomp.nb for people without Mathematica.

PNG files: these were captured from Marc Olano's "ShaderTest" framework which was set up to do importance sampling on a "furnace" (constant RGB of 1.0,0.75,0.5) environment. Each file is a 1D strip cut out of a larger frame. These strips were selected so as to cover all values of (N dot V) present in the render. For each gloss value, two renders were made: one writing values of (N dot V) to the frame buffer and one importance-sampled ground truth image. The reason a separate (N dot V) image was rendered out for each gloss value is that the camera was moved each time the gloss value was changed (in hindsight probably avoidable) so the same (N dot V) image couldn't be reused. The different gloss values were captured with different linear gains applied on the render so that the result would fit in an 8-bit frame buffer with minimal clipping. The gain value is encoded in the file name. These PNG files are loaded by bo2-prefiltered-env.nb.

groundstrip_furnace_g000_gain_23_7.png: Ground truth strip for gloss 0.0, with gain of 23.7.
groundstrip_vdotn_g000.png: (V dot N) values for gloss 0.0 strip.
groundstrip_furnace_g050_gain_4_89.png: Ground truth strip for gloss 0.5, with gain of 4.89.
groundstrip_vdotn_g050.png: (V dot N) values for gloss 0.5 strip.
groundstrip_furnace_g100_gain_2_26.png: Ground truth strip for gloss 1.0, with gain of 2.26.
groundstrip_vdotn_g100.png: (V dot N) values for gloss 1.0 strip.


README.txt: this file.




